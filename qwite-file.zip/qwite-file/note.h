#ifndef NOTE_H
#define NOTE_H
/*
 author:ranxudong
 date:2019.4.29
 文本编辑器的简单实现
 以实现功能：new，open，save,close,exit,find,replace功能

*/


#include<QMainWindow>
#include"mysyntaxhighlighter.h"

class QTextEdit;
class QAction;
class FindDialog;
//class MySyntaxHighlighter;
class QTextDocument;
class ReplaceDialog;

class NotePad : public QMainWindow
{
    Q_OBJECT

public:
    NotePad();
    ~NotePad();

private slots:
    void newFile();
    void open();
    bool save();
    void saveAs();

    void selectColor();      //选择字体颜色
    void selectFont();       //选择字体风格

    void closeEvent(QCloseEvent* event);
    void find();             //逐个查找关键字
    void findNext(const QString &str, Qt::CaseSensitivity cs);
//    void findPrevious(const QString &str, Qt::CaseSensitivity cs);
    void findAll(const QString &str, Qt::CaseSensitivity cs);

    void toReplace();
    void replace(QString &str1,QString &str2);
private:

    void createActions();
    void createMenus();
    void createContextMenu();
    void createToolBars();

//    bool okToContinue();
//    bool loadFile();


    QTextEdit *textEdit ;
    QString curFile;
    FindDialog *findDialog;
    MySyntaxHighlighter *highlighter;
    QTextDocument *document ;
    ReplaceDialog *replaceDialog;

    void setCurrentFile(const QString &fileName);


    QMenu *fileMenu;
    QMenu *editMenu;
    QMenu *helpMenu;

    //file
    QAction *newAction;
    QAction *openAction;
    QAction *saveAction;
    QAction *saveAsAction;
    QAction *closeAction;
    QAction *exitAction;



    //edit
    QAction *cutAction;
    QAction *copyAction;
    QAction *pasteAction;
    QAction *deleteAction;

    QAction *undoAction;
    QAction *redoAction;

    QAction *fontColor;
    QAction *fontStyle;

    QAction *findAction;
    QAction *replaceAction;


    QToolBar *fileToolBar;
    QToolBar *editToolBar;




};

#endif // NOTE_H

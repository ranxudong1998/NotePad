#ifndef REPLACE_H
#define REPLACE_H

#include <QDialog>

namespace Ui {
class ReplaceDialog;
}

class ReplaceDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ReplaceDialog(QWidget *parent = nullptr);
    ~ReplaceDialog();
signals:
    void replace(QString &str1, QString &str2 );

private slots:
    void replaceClicked();


private:
    Ui::ReplaceDialog *ui;
};

#endif // REPLACE_H

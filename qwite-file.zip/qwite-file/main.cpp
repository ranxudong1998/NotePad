#include "note.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    NotePad notepad;
    notepad.show();

    return a.exec();
}

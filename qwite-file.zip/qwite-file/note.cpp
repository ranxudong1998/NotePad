#include<QtWidgets>
#include<QTextEdit>
#include<QFile>
#include<QTextDocument>

//#include"mysyntaxhighlighter.h"
#include "note.h"
#include"finddialog.h"
#include"replace.h"


NotePad::NotePad()
{
    textEdit = new QTextEdit;
    setCentralWidget(textEdit);

    createActions();
    createMenus();
    createToolBars();
    createContextMenu();

    findDialog = 0;
    replaceDialog = 0;
    setWindowTitle("NotePad");


}

void NotePad::createActions()
{
    newAction = new QAction(tr("&New"),this);
    newAction->setIcon(QIcon(":/images/new.png"));
    newAction->setShortcut(QKeySequence::New);
    //QKeySequence::StandardedKey   此枚举代表标准键绑定。ta们可用于为QAction分配平台相关的键盘快捷键。
    connect(newAction,&QAction::triggered,this,&NotePad::newFile);

    openAction = new QAction(tr("&Open"),this);
    openAction->setIcon(QIcon(":/images/open.png"));
    openAction->setShortcut(QKeySequence::Open);
    connect(openAction,&QAction::triggered,this,&NotePad::open);

    saveAction = new QAction(tr("&Save"),this);
    saveAction->setIcon(QIcon(":/images/save.png"));
    saveAction->setShortcut((QKeySequence::Save));
    connect(saveAction,&QAction::triggered,this,&NotePad::save);


    closeAction = new QAction(tr("close"), this);
    connect(closeAction,&QAction::triggered,this,&QWidget::close);

    exitAction = new QAction(tr("E&xit"), this);
    exitAction->setShortcut(tr("Ctrl+X"));
    exitAction->setStatusTip(tr("Exit the application"));
    connect(exitAction,&QAction::triggered,this,&QWidget::close);

    cutAction = new QAction(tr("&Cut"),this);
    cutAction->setIcon(QIcon(":/images/cut.png"));
    cutAction->setShortcut(QKeySequence::Cut);
    connect(cutAction,&QAction::triggered,textEdit, &QTextEdit::cut);

    copyAction = new QAction(tr("&Copy"),this);
    copyAction->setIcon(QIcon(":/images/copy.png"));
    copyAction->setShortcut(QKeySequence::Copy);
    connect(copyAction,&QAction::triggered,textEdit, &QTextEdit::copy);

    pasteAction = new QAction(tr("&Paste"),this);
    pasteAction->setIcon(QIcon(":/images/paste.png"));
    pasteAction->setShortcut(QKeySequence::Paste);
    connect(pasteAction,&QAction::triggered,textEdit, &QTextEdit::paste);

    undoAction = new QAction(tr("&Undo"),this);
    undoAction->setIcon(QIcon(":/images/undo.png"));
    undoAction->setShortcut(QKeySequence::Undo);
    connect(undoAction,&QAction::triggered,textEdit, &QTextEdit::undo);

    redoAction = new QAction(tr("&Redo"),this);
    redoAction->setIcon(QIcon(":/images/redo.png"));
    redoAction->setShortcut(QKeySequence::Redo);
    connect(redoAction,&QAction::triggered,textEdit,&QTextEdit::redo);

    fontColor = new QAction(tr("&Font color"),this);
    connect(fontColor,&QAction::triggered,this,&NotePad::selectColor);

    fontStyle = new QAction(tr("&Font style"),this);
    connect(fontStyle,&QAction::triggered,this,&NotePad::selectFont);

    findAction = new QAction(tr("&Find..."), this);
    findAction->setIcon(QIcon(":/images/find.png"));
    findAction->setShortcut(QKeySequence::Find);
    findAction->setStatusTip(tr("Find a matching words"));
    connect(findAction, &QAction::triggered,this,&NotePad::find);

    replaceAction = new QAction(tr("&Replace"), this);
    replaceAction->setIcon(QIcon(":/images/find.png"));
    replaceAction->setShortcut(QKeySequence::Replace);
    replaceAction->setStatusTip(tr("Find a matching words"));
    connect(replaceAction, &QAction::triggered,this,&NotePad::toReplace);


}

/*创建菜单QMenu*/
void NotePad::createMenus()
{
    fileMenu = menuBar()->addMenu(tr("&File"));
    fileMenu->addAction(newAction);
    fileMenu->addAction(openAction);
    fileMenu->addAction(saveAction);
    fileMenu->addAction(closeAction);
    fileMenu->addAction(exitAction);

    editMenu = menuBar()->addMenu(tr("&Edit"));
    editMenu->addAction(cutAction);
    editMenu->addAction(copyAction);
    editMenu->addAction(pasteAction);
    editMenu->addSeparator();
    editMenu->addAction(undoAction);
    editMenu->addAction(redoAction);

    editMenu->addSeparator();
    editMenu->addAction(fontColor);
    editMenu->addAction(fontStyle);
    editMenu->addSeparator();
    editMenu->addAction(findAction);
    editMenu->addAction(replaceAction);

    helpMenu  = menuBar()->addMenu(tr("&Help"));



}

/*创建上下文菜单*/
void NotePad::createContextMenu()
{
    textEdit->addAction(cutAction);
    textEdit->addAction(copyAction);
    textEdit->addAction(pasteAction);
    textEdit->addAction(undoAction);
    textEdit->addAction(redoAction);
    textEdit->addAction(fontColor);
    textEdit->addAction(fontStyle);

    textEdit->setContextMenuPolicy(Qt::ActionsContextMenu);
}

/*创建工具栏*/
void NotePad::createToolBars()
{
    fileToolBar = addToolBar(tr("&File"));
    fileToolBar->addAction(newAction);
    fileToolBar->addAction(openAction);
    fileToolBar->addAction(saveAction);
    //fileToolBar->addAction(closeAction);

    editToolBar = addToolBar(tr("&Edit"));
    editToolBar->addAction(cutAction);
    editToolBar->addAction(copyAction);
    editToolBar->addAction(pasteAction);
    editToolBar->addSeparator();
    editToolBar->addAction(undoAction);
    editToolBar->addAction(redoAction);
    editToolBar->addAction(findAction);
    editToolBar->addAction(replaceAction);


}


void NotePad::newFile()
{
    curFile.clear();
    textEdit->setText(QString());
}


void NotePad::open()
{
    QString fileName;
    //if(okToContinue()){
    //QFileDialog::getOpenFileName(父窗口部件，title，从哪一级目录开始，指定文件过滤器)
    //getOpenFileName（）静态函数从用户那里获得一个新文件名
    fileName = QFileDialog::getOpenFileName(this,
                                            tr("open NotePad"));
    //}
    QFile file(fileName);  //构造一个以name为文件名的QFile对象。
    curFile = fileName;

    if(!file.open(QIODevice::ReadOnly | QFile::Text)){
        QMessageBox::warning(this,"Warning","Cannot open file:"+file.errorString());
        return;
    }
    setWindowTitle(fileName);
    QTextStream in(&file);
    QString text = in.readAll();
    textEdit->setText(text);
    file.close();

}


bool NotePad::save()
{
    if(curFile.isEmpty()){
        saveAs();
        return true;
    }else {
        return false;
    }
}

void NotePad::saveAs()
{
    QString fileName = QFileDialog::getSaveFileName(this, "Save as");
    QFile file(fileName);

    if (!file.open(QFile::WriteOnly | QFile::Text)) {
        QMessageBox::warning(this,
                             "Warning",
                             "Cannot save file: " + file.errorString());
        return;
    }
    curFile = fileName;
    setWindowTitle(fileName);
    QTextStream out(&file);
    QString text = textEdit->toPlainText();
    out << text;
    file.close();

}
void NotePad::closeEvent(QCloseEvent* event)
{
    int c = QMessageBox::warning(this,tr("NotePad"),
                                 tr("Do you want to close the NotePad!"),
                                 QMessageBox::Yes |
                                 QMessageBox::No |
                                 QMessageBox::Cancel);
    if(c == QMessageBox::Yes){
       save();
       event->accept();      //接受事件
    }else {


    }
}

void NotePad::find()
{
    if (!findDialog) {
        findDialog = new FindDialog(this);

        connect(findDialog,&FindDialog::findAll,this,&NotePad::findAll);
        connect(findDialog,&FindDialog::findNext,this,&NotePad::findNext);

    }
    findDialog->show();
    findDialog->raise();
    findDialog->activateWindow();

}

void NotePad::findNext(const QString &str, Qt::CaseSensitivity cs)
{
    if(textEdit->find(str,QTextDocument::FindWholeWords)){
        QPalette palette = textEdit->palette();
        palette.setColor(QPalette::Highlight,palette.color(QPalette::Active,QPalette::Highlight));
        textEdit->setPalette(palette);
    }
}
void NotePad::findAll(const QString &str, Qt::CaseSensitivity cs)
{

    document = textEdit->document();
    document->undo();                         //撤销标记
    bool found = false;
    QTextCursor highlightCursor(document);
    QTextCursor cursor(document);

    cursor.beginEditBlock();

    QTextCharFormat plainFormat(highlightCursor.charFormat());
    QTextCharFormat colorFormat = plainFormat;
    colorFormat.setForeground(Qt::red);

    while (!highlightCursor.isNull() && !highlightCursor.atEnd()) {
        highlightCursor = document->find(str, highlightCursor,
                                         QTextDocument::FindWholeWords);

        if (!highlightCursor.isNull()) {
            found = true;
            //MoveAnchor表示普通的移动光标，不选中任何内容
            //KeepAnchor表示移动光标的同时选中之间的内容
            highlightCursor.movePosition(QTextCursor::WordRight,
                                         QTextCursor::KeepAnchor);
            highlightCursor.mergeCharFormat(colorFormat);
        }
    }

    cursor.endEditBlock();
    if (found == false) {
        QMessageBox::information(this, tr("Word Not Found"),
                                 tr("Sorry, the word cannot be found."));
    }
}

void NotePad::toReplace()
{
    if (!replaceDialog) {
         replaceDialog = new ReplaceDialog(this);

         connect(replaceDialog,&ReplaceDialog::replace,this,&NotePad::replace);


     }
     replaceDialog ->show();
     replaceDialog ->raise();
     replaceDialog ->activateWindow();
}

void NotePad::replace(QString &str1,QString &str2)
{
    qDebug()<< str1 <<"    "<<str2;
    document = textEdit->document();
    document->undo();     //撤销标记
    bool found = false;
    QTextCursor highlightCursor(document);
    QTextCursor cursor(document);

    cursor.beginEditBlock();

    QTextCharFormat plainFormat(highlightCursor.charFormat());
    QTextCharFormat colorFormat = plainFormat;
    colorFormat.setForeground(Qt::red);

    while (!highlightCursor.isNull() && !highlightCursor.atEnd()) {
        highlightCursor = document->find(str1, highlightCursor,
                                         QTextDocument::FindWholeWords);

        if (!highlightCursor.isNull()) {
            found = true;
            //MoveAnchor表示普通的移动光标，不选中任何内容
            //KeepAnchor表示移动光标的同时选中之间的内容
            highlightCursor.movePosition(QTextCursor::WordRight,
                                         QTextCursor::KeepAnchor);

            highlightCursor.deleteChar();
            highlightCursor.insertText(str2,colorFormat);
            //highlightCursor.mergeCharFormat(colorFormat);
        }
    }

    cursor.endEditBlock();
    if (found == false) {
        QMessageBox::information(this, tr("Word Not Found"),
                                 tr("Sorry, the word cannot be found."));
    }
}



//void NotePad::findPrevious(const QString &str,Qt::CaseSensitivity cs)
//{
//    textEdit->find(str);
//    QApplication::beep();
//}
//设置字体颜色
void NotePad::selectColor()
{
    QPalette Palette = textEdit->palette();
    QColor Color = QColorDialog::getColor(Qt::blue,this,"设置字体颜色");
    if(Color.isValid())
    {
        Palette.setColor(QPalette::Text,Color);
        textEdit->setPalette(Palette);
    }
}

//设置字体风格（大小，类型）
void NotePad::selectFont()
{
    bool ok;
    // QFontDialog::getFont(bool *ok, QWidget *parent = nullptr,)
    QFont Font = QFontDialog::getFont(&ok,textEdit->font(),this,tr("字体设置"));
    if(ok)
    {
        textEdit->setFont(Font);
    }

}

NotePad::~NotePad()
{

}

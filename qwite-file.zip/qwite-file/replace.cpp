#include "replace.h"
#include "ui_replace.h"

ReplaceDialog::ReplaceDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ReplaceDialog)
{
    ui->setupUi(this);
    connect(ui->closeButton,&QPushButton::clicked,this,&QPushButton::close);
    connect(ui->okButton,&QAbstractButton::clicked,this, &ReplaceDialog::replaceClicked);
}

ReplaceDialog::~ReplaceDialog()
{
    delete ui;
}

void ReplaceDialog::replaceClicked()
{
    QString text1 = ui->lineEdit_1->text();              //获取被替换的字符串
    QString text2 = ui->lineEdit_2->text();              //获取替换字符
    emit replace(text1,text2);

}
